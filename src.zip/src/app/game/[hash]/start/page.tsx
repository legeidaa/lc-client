import RegistrationForms from "@/shared/components/RegistrationForms/RegistrationForms";

export default function StartPage() {
    return (
        <div className="container">
            <RegistrationForms />
        </div>
    );
}
