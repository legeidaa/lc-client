import { FC, useEffect, useState } from "react";
import { useUpdateActionsMutation } from "@/lib/redux/gameApi";
import { useGetActionsListData } from "@/shared/hooks/useGetActionsListData";
import { LoadingSpinner } from "../LoadingSpinner/LoadingSpinner";
import { InputsListEstimates } from "../InputsListEstimates/InputsListEstimates";
import { Action } from "@/shared/interfaces/game";

export const ActionsListEstimatesContoller: FC = () => {
    const { actions, isActionsLoadingSuccess } =
        useGetActionsListData();

    const [updateActions, { isLoading: isUpdateActionsLoading }] =
        useUpdateActionsMutation();

    const [isSomeFieldsEmpty, setIsSomeFieldsEmpty] = useState(false);
    const [localActions, setLoacalActions] = useState<Action[]>([]);

    useEffect(() => {
        if (isActionsLoadingSuccess && actions) {
            setLoacalActions(actions);
        }
    }, [actions, isActionsLoadingSuccess]);

    const onInputChange = (value: string, i: number) => {
        if (value.length > 3) {
            return;
        }
        if(Number(value) > 100) {
            value = "100";
        }
        
        const newItems = [...localActions];
        if (newItems[i]) {
            const newItem = { ...newItems[i] };
            newItem.estimate = Number(value);
            newItems[i] = newItem;
            setLoacalActions(newItems);
        }
        const isSomeFieldsEmpty = newItems.some((item) => !item.title);
        if (!isSomeFieldsEmpty) {
            setIsSomeFieldsEmpty(false);
        }
    };

    const saveData = async () => {
        const isSomeFieldsEmpty = localActions.some(
            (item) => !item.estimate
        );
        
        if (isSomeFieldsEmpty) {
            setIsSomeFieldsEmpty(true);
            return;
        }
        updateActions(localActions);
    };

    if (!isActionsLoadingSuccess || !actions) {
        return <LoadingSpinner />;
    }

    return (
        <InputsListEstimates
            actions={localActions}
            isReadyBtnDisabled={isUpdateActionsLoading}
            placeholder=""
            onInputChange={onInputChange}
            onReadyClick={saveData}
            isSomeFieldsEmpty={isSomeFieldsEmpty}
        />
    );
};
